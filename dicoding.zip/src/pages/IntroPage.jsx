import React from "react";
import SlideShow from "../components/SlideShow";

function IntroPage() {
    return (
         <SlideShow />
    )
}

export default IntroPage;